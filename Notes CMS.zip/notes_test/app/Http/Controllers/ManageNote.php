<?php

namespace App\Http\Controllers;

use App\Http\Controllers\notesController;

use Illuminate\Http\Request;

use App\Models\Notes;

//use Illuminate\Http\UploadedFile::getClientOriginalName();

class ManageNote extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $notes = Notes::select ('*')
                ->where ('is_deleted' , '!=' ,   "Yes")
                ->get();

        $msg = "There are no notes now .. you can add new note from ..";

        /*if(empty($notes)//->isEmpty())
        {
            return view ('Notes.homeWithoutNotes' , compact('msg'));
        }*/

        return view('Notes.home', compact('notes'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Notes.add_notes');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request->all());
        if($request->hasFile('img'))
        {
            $image = $request->img;
            $new_img = time().$image->getClientOriginalName();
            $image->move('notes-images', $new_img);
        }
        Notes::create([

            "content" => $request->note,
            "type" => $request->type,
            "image" => 'notes-images/'.$new_img,
            "share" => "",

        ]);



        return redirect()->back()->with('msg' , 'The note added successfully..');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $notes = Notes::find($id);
        return view('Notes.edit' , compact('notes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $notes = Notes::find($id);

        if($request->hasFile('img'))
        {
            $image = $request->img;
            $new_img = time().$image->getClientOriginalName();
            $image->move('notes-images',$new_img);
            $notes->image = 'notes-images/'.$new_img;


        }

        $notes->content = $request->note;
        $notes->type = $request->type;
        $notes->update();

        $msg = "The note edit successfully .. please press on the button 'Home' to return to home page and see the edit";
        return view('Notes.afterEdit', compact('msg'));



    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $notes = Notes::find($id);
        $notes->is_deleted = "Yes";
        $notes->update();

        return redirect()->back();
    }

}
