<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Notes;
use DB;

class notesController extends Controller
{


    public function get_report()
    {
        return view('Notes.get_report');
    }

    public function generate_report(Request $request)
    {
        $type_note = $request->type;

        $notes =  DB::table('notes')->where('type', '=', $request->type)
        ->where('is_deleted' , '!=' , 'Yes')->get();

        return view('Notes.generate' , compact('notes'));
    }

    public function welcome()
    {

        $notes =DB::table('notes')->where('is_deleted' , '=' , 'no')
                                  ->get();

        return view('welcome', compact('notes'));
    }

    public function share($id)
    {

        /*$notes = Notes::find($id);
        $notes->share = "Yes";
        $notes->update();
*/

        $notes =DB::table('notes')->where('id' , '=' , $id)
        ->get();

        return view('Notes.share', compact('notes'));
    }





}
