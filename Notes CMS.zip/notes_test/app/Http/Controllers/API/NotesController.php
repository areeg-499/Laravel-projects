<?php

namespace App\Http\Controllers\API;


use Illuminate\Http\Request;

use App\Models\Notes;
use Validator;
use App\Http\Resources\note as noteResource;
use App\Http\Controllers\API\BaseController as BaseController;

class NotesController extends BaseController
{
     /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */

    public function index()
    {
        $notes = Notes::select ('*')
                ->where ('is_deleted' , '!=' ,   "Yes")
                ->get();

        return $this->sendResponse(noteResource::collection($notes),
                                   'All available notes sent');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */


     /*public function show($id)
    {
        $note = Notes::find($id);
        if ( is_null($note) ) {
            return $this->sendError('note not found'  );
              }
              return $this->sendResponse(new noteResource($note) ,'note found successfully' );

    }*/

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $notes = $request->all();
        $validator = Validator::make($notes , [
            'content'=> 'required',
            'type'=> 'required',
            'image'=> 'required'
           ]  );

           if ($validator->fails()) {
            return $this->sendError('Please validate error' ,$validator->errors() );
              }

        $product = Notes::create($notes);
        return $this->sendResponse(new noteResource($product) ,'Note added successfully' );


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

        public function update(Request $request, Notes $note)
    {
        $input = $request->all();
        $validator = Validator::make($input , [
         'content'=> 'required',
         'type'=> 'required',
         'image'=> 'required'
        ]  );

        if ($validator->fails()) {
         return $this->sendError('Please validate error' ,$validator->errors() );
           }
     $note->content = $input['content'];
     $note->type = $input['type'];
     $note->image = $input['image'];
     $note->save();
     return $this->sendResponse(new noteResource($note) ,'Note updated successfully' );

    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $notes = Notes::find($id);
        $notes->is_deleted = "Yes";
        $notes->update();

        return $this->sendResponse(new noteResource($notes) ,'Note deleted successfully' );
    }

}

