@extends('Notes.layout')

@section('content')

<div class="container">
 <table class="table table-dark table-striped">


          <thead>
            <tr>
              <th><h2 style="margin: 2% 0% 2% 0%">New note</h2></th>
            </tr>
        </thead>
        <tbody style="margin-left: 2%">
            <tr>
                <td>
        <form action="{{route('notes.store')}}" method="post" enctype="multipart/form-data" style="width: 50%">

            @csrf

            <div class="form-group">
            <label for="note">Note:</label>
            <textarea class="form-control" rows="5" id="note" placeholder="Enter your Note" name="note" required></textarea>
            </div>

            <div class="form-group">
                <label for="img">Image:</label>
                <input type="file" class="form-control" id="img" placeholder="Enter Image for note" name="img" required>
            </div>

            <div class="form-group">
                <label for="type">Type:</label>
                <select class="form-control" id="type" name="type" required>
                    <option name="">urgent</option>
                    <option name="">normal</option>
                    <option name="">on date</option>
                </select>
            </div>


            <button type="submit" class="btn btn-primary">Add</button>
            <!--<button type="button" class="btn btn-info" value="No">Share</button>--->
        </form>
                </td>
     </tr>
        </tbody>
 </table>
</div>

@endsection
