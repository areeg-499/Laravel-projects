@extends('Notes.layout')

@section('content')


    <div class="container-fluid">
        <h2 class="title" style="margin:2% 0% 2% 0%">Notes Report</h2>
        <table class="table table-dark table-striped" style="margin-top: 0%; ">
          <thead>
            <tr>
              <th>Note</th>
              <th>Type</th>
              <th>Image</th>
              <th>Control Buttons</th>
            </tr>
          </thead>
          <tbody>
              @foreach($notes as $note)
            <tr>
              <td>{{$note->content}}</td>
              <td>{{$note->type}}</td>
              <td>
                  <img src="{{$note->image}}" alt="{{$note->image}}" style="width:100px ; height:100px"/>
              </td>
              <td>
                  <button type="button" class="btn btn-success">Share</button>
                  <button type="button" class="btn btn-warning"><a href="{{route('notes.edit' , ['id'=>$note->id])}}">Edit</a></button>
                  <button type="button" class="btn btn-danger"><a href="{{route('notes.delete' , ['id'=>$note->id])}}">Delete</a></button>
                 <!-- <button type="button" class="btn btn-info"><a href="{{route('add_notes')}}">Add</a></button>-->
              </td>
            </tr>
           @endforeach

          </tbody>
        </table>
      </div>

@endsection
