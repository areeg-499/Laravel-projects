@extends('Notes.layout')

@section('content')

<div style="background: darkgrey;margin: 5%;padding: 20px;border-radius: 10px;" >
    <span style="padding: 15px">{{$msg}}</span>
    <a href="/home" role="" class="btn btn-primary" >Home</a>
    <!--<button type="button" class="btn btn-primary"><a href="/home">Home</a></button>-->
</div>

@endsection
