<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--home-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!--generate-->


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #454d55;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
 // background-color: #04AA6D;
 // color: white;
  margin-left: 60%;
}

.logo
{
    margin-left: 10%;
}
.topnav .icon {
  display: none;
}

a
     {
         color: #fff;
         text-decoration: none;
     }
     a:hover , a:focus
     {
        text-decoration: none;
        color: #fff;
     }

     .card-style
     {
        padding: 0px 10px 0px 10px;
     }
     .card
     {
        background: darkgrey;
        margin-bottom: 8%;
     }
     .table-dark
     {
        margin-top: 5%;

     }

a , h1 , h2 ,h5 , span , p
{
    font-family:Arial, Helvetica, sans-serif;
}

.title
{
     margin:2% 0% 2% 0% ;
     background: darkgrey;
     width:300px;
     text-align:center;
     padding:1%;
     border-radius:0px 20px 20px;
}

@media screen and (max-width: 1300px) {
    .logo
{
    margin-left: 0%;
}

.topnav a.active
{
    margin-left: 40%;
}
}
@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }

  .logo
{
    margin-left: 0%;
}

.topnav a.active
{
    margin-left: 0%;
}

}
</style>
</head>
<body>

<div class="topnav" id="myTopnav">
  <a href="/home" class="logo" name="logo" >Notes</a>
  <a href="/home" class="active">Home</a>
  <a href="add_notes">Add note</a>
  <a href="get_report">Get report</>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>

@yield('content')

<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>
