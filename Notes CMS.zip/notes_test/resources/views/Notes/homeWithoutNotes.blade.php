<!DOCTYPE html>
<html lang="en">
<head>
  <title>List of saved notes</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

<style>
    a
    {
        color: #fff;
        text-decoration: none;
    }
    a:hover , a:focus
    {
       text-decoration: none;
       color: #fff;
    }
 </style>
</head>
<body>
<div style="background: coral;margin-top:2%;padding: 3% 0% 3% 3%;">
<span style="text-align: left;font-size: x-large;font-weight: 500;">
    {{$msg}}
</span>
<button type="button" class="btn btn-info"><a href="{{route('add_notes')}}">Add</a></button>

</div>
</body>
</html>
