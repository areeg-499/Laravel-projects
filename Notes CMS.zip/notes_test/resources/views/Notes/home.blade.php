@extends('Notes.layout')

@section('content')

<style>
    .important
    {
        display: none;
    }
    .modal-content
            {
                display: inline-table;
                margin-top: 15%;
                height: 300px;
                width:50%;
            }

    </style>
<div class="container-fluid">
  <h2 class="title" style="margin:2% 0% 2% 0% ; background: darkgrey;width:200px;text-align:center;padding:1%;border-radius:0px 20px 20px">My notes</h2>
</div>
<div class="container-fluid">

    <div class="row">

        @foreach($notes as $note)

        <div class=" col-md-3">

            <div class="card" id="note" name="note" style="600px">
                <div class="card-img" style="    ">
                    <img src="{{$note->image}}" alt="{{$note->image}}" style="width:100%;height: 230px;"/>
                </div>

                <div class="card-note  card-style" style="height: 120px;">
                    <p style="">{{$note->content}}</p>
                </div>

                <div class="card-type  card-style" >
                    <h5>{{$note->type}}</h5>
                </div>

                <div class="control card-style" style="text-align: center;margin: 10px 0px 10px 0px;">


                    <button type="button" class="btn btn-success" id="share"  >Share</button>

                        <div id="myModal" class="modal"style="margin-top:10px;background: darkgrey;">
                            <!-- Modal content -->
                            <div class="modal-content" >
                            <span class="close" style="margin: 10px;">&times;</span>
                            <h5 style="margin-top: 20px;">You can share this note with any person only send the link:</h5>
                            <h5> http://127.0.0.1:8000/share/{{$note->id}} </h5>

                            </div>
                        </div>

                    <button type="button" class="btn btn-warning"><a href="{{route('notes.edit' , ['id'=>$note->id])}}">Edit</a></button>
                    <button type="button" class="btn btn-danger"><a href="{{route('notes.delete' , ['id'=>$note->id])}}" onclick="buttonCheck2()">Delete</a></button>
                </div>


            </div>
        </div>
        @endforeach
    </div>

</div>


<script>


$(document).ready(function(){

$("#share").click(function(){
  $("#myModal").fadeIn();
    });


    $(".close").click(function(){
     $("#myModal").css('display' , 'none');
    });
});
function buttonCheck2(){

    alert("You delete a note ...");

    }



</script>

@endsection


