@extends('Notes.layout')

@section('content')


<div class="container">
 <table class="table table-dark table-striped">


          <thead>
            <tr>
              <th><h2 style="margin: 2% 0% 2% 0%">Choose type of notes to generate report</h2></th>
            </tr>
        </thead>
        <tbody style="margin-left: 2%">
            <tr>
                <td>
        <form action="{{route('generate_report')}}" method="post" style="width: 50%">

            @csrf



            <div class="form-group">
                <label for="type">Type:</label>
                <select class="form-control" id="type" name="type">
                    <option name="">urgent</option>
                    <option name="">normal</option>
                    <option name="">on date</option>
                </select>
            </div>


            <button type="submit" class="btn btn-primary">Get report</button>

        </form>
                </td>
     </tr>
        </tbody>
 </table>
</div>

@endsection
