@extends('Notes.layout')

@section('content')

<style>
    .important
    {
        display: none;
    }
    </style>
<div class="container-fluid">
  <h2 class="title" style="margin:2% 0% 2% 0% ; background: darkgrey;width:250px;text-align:center;padding:1%;border-radius:0px 20px 20px">Shared notes</h2>
</div>
<div class="container-fluid">

    <div class="row">

        @foreach($notes as $note)

        <div class=" col-md-3">

            <div class="card" id="note" name="note" style="600px">
                <div class="card-img" style="">
                    <img src="../{{$note->image}}" alt="{{$note->image}}" style="width:100%;height: 230px;"/>
                </div>

                <div class="card-note  card-style" style="height: 120px;">
                    <p style="">{{$note->content}}</p>
                </div>

                <div class="card-type  card-style" >
                    <h5>{{$note->type}}</h5>
                </div>



            </div>
        </div>
        @endforeach
    </div>



</div>


@endsection


