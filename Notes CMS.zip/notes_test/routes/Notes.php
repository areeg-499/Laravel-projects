<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\notesController;
use App\Http\Controllers\ManageNote;
use App\Models\Notes;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified'
])->group(function () {
    Route::get('/dashboard', function () {
        $notes = Notes::select ('*')
                ->where ('is_deleted' , '!=' ,   "Yes")
                ->get();
        return view('Notes.home'  , compact('notes'));
    })->name('dashboard');
});






Route::get('share/{id}' , [notesController::class,'share'])->name('notes.share');


Route::middleware('auth:sanctum')->group(function(){

    Route::get('/',[notesController::class,'welcome']);

    Route::get('/home',[ManageNote::class,'index']);

    Route::get('add_notes' , [ManageNote::class,'create'])->name('add_notes');

    Route::post('add_notes/store' , [ManageNote::class,'store'])->name('notes.store');

    Route::get('Notes/edit/{id}', [ManageNote::class,'edit'])->name('notes.edit');

    Route::post('add_notes/update/{id}' , [ManageNote::class,'update'])->name('notes.update');

    Route::get('Notes/delete/{id}', [ManageNote::class,'destroy'])->name('notes.delete');

    Route::get('/lay', function () {
        return view('Notes.layout');
    });

    Route::get('get_report',[notesController::class,'get_report']);

    Route::post('generate_report' ,[notesController::class,'generate_report'])->name('generate_report');



});

