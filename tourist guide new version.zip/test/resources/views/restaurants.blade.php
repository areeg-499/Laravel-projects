@extends('layouts.app')

@section('content')

 <section class="ftco-section bg-light">

      <div class="container">
        <h3 class="nav-link ">Restorants in Syria</h3>
        <div class="row d-flex">
          <div class="col-md-12 d-flex ftco-animate">
           <div class="single-slider owl-carousel">
                 <div class="item">
                    <div class="hotel-img" style="background-image: url(images/hotel-2.jpg);"></div>
                  </div>
                  <div class="item">
                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
                  </div>
                  <div class="item">
                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
         

            </div></div></div>
            
          </div>
    
		 <h5 class="nav-link align-items-center" >Oriental Restaurants</h5>

		   <!-- <div class="container">-->
		        <div class="row d-flex">
		          <div class="col-md-6 d-flex ftco-animate">
		            <div class="single-slider owl-carousel">
		                 <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-2.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
		           <!--  <a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
		              </a>-->

		            </div></div></div></div>
		            
		 <h5 class="nav-link align-items-center" >Western restaurants</h5>
		                <!--<div class="container">-->
		        <div class="row d-flex">
		          <div class="col-md-6 d-flex ftco-animate">
		            <div class="single-slider owl-carousel">
		                 <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-2.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
		           <!--  <a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
		              </a>-->

		            </div></div></div></div>

		<h5 class="nav-link align-items-center" >Fast food restaurants</h5>
		


		               <!-- <div class="container">-->
		        <div class="row d-flex">
		          <div class="col-md-6 d-flex ftco-animate">
		            <div class="single-slider owl-carousel">
		                 <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-2.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
		           <!--  <a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
		              </a>-->

		            </div></div></div></div>

		 <h5 class="nav-link align-items-center" > restaurant & Cafe</h5>
		                <!--<div class="container">-->
		        <div class="row d-flex">
		          <div class="col-md-6 d-flex ftco-animate">
		            <div class="single-slider owl-carousel">
		                 <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-2.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
		           <!--  <a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
		              </a>-->

		            </div></div></div></div>


		 <h5 class="nav-link align-items-center" >Cafe</h5>
		                <!--<div class="container">-->
		        <div class="row d-flex">
		          <div class="col-md-6 d-flex ftco-animate">
		            <div class="single-slider owl-carousel">
		                 <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-2.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
		           <!--  <a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
		              </a>-->

		            </div></div></div></div>


		 <h5 class="nav-link align-items-center" >Cafeteria</h5>
		                <!--<div class="container">-->
		        <div class="row d-flex">
		          <div class="col-md-6 d-flex ftco-animate">
		            <div class="single-slider owl-carousel">
		                 <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-2.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
		                  </div>
		                  <div class="item">
		                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
		           <!--  <a href="blog-single.html" class="block-20" style="background-image: url('images/image_1.jpg');">
		              </a>-->

		            </div></div></div></div>

		          </div>  
		          </section>
    
      @foreach($restaurants as $restuarant)
       @if({{ $restuarant->SITE}})<!----if restaurant only or cafe or.....---->s
      <div><h2>Popular Restorant</h2></div>
      <div class="col-lg-12">
            <div class="row">
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-1.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#"> {{ $restuarant->SITE}} </a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-2.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">{{ $restuarant->SITE}}</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-3.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">{{ $restuarant->SITE}}</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-4.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">{{ $restuarant->SITE}}</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">{{ $restuarant->SITE}}</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                        <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">{{ $restuarant->SITE}}</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
</div>
@endif
<!---------------------Restorant and cafe---------------------------------------------------------------->


      <div><h2>Popular Restorant and cafe</h2></div>
      <div class="col-lg-12">
            <div class="row">
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-1.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">AlKaissar palace</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-2.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Four sesons</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-3.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Alsham palace</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-4.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Bet Alfan</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Blue tower</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                        <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Crystal palace</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
</div>




<!---------------------cafe---------------------------------------------------------------->


      <div><h2>Popular cafe</h2></div>
      <div class="col-lg-12">
            <div class="row">
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-1.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3>AlKaissar palace</h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-2.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3>Four sesons</h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-3.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3>Alsham palace</h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-4.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3>Bet Alfan</h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3>Blue tower</h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                        <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3>Crystal palace</h3>
                        <p class="rate"
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
</div>



<!---------------------cafeteria---------------------------------------------------------------->


      <div><h2>Popular cafeteria</h2></div>
      <div class="col-lg-12">
            <div class="row">
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-1.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">AlKaissar palace</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-2.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Four sesons</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-3.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Alsham palace</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-4.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Bet Alfan</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Blue tower</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                        <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Crystal palace</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
</div>
@endforeach




@endsection