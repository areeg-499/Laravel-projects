@extends('layouts.app')


@section('content')

<div class="container"> 


@foreach($results as $hotel)

<h2>Name of hotel:</h2>{{$hotel->SITE}}<hr />

<img src="/images/{{$hotel->image}}"; width="100%"; height="500px"/>

<h2>Location :</h2>{{$hotel->CITY}}{{$hotel->street}}<hr />

<h2>The rank of hotel:</h2>{{$hotel->Rank}}<hr />

<h2>telephone :</h2>{{$hotel->telephone}}<hr />
<h2>website :</h2>{{$hotel->website}}<hr />

<h2>Description :</h2>{{$hotel->DESC_ALL}}<hr />

@endforeach
</div>
@endsection