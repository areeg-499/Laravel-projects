@extends('layouts.app')

@section('content')


    <div class="hero-wrap js-fullheight" style="background-image: url(bg_1.jpg) " >
      <div class="overlay"></div>
      <div class="container">

        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-9 text-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">

            <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.html" style="color: #990000">Home</a></span> <span style="color: #332200">Contact</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }" style="font-size: 30px;color: #73264d">Contact us</h1>
           
           

           
           </div>
           </div>
           </div>
           </div> 



    <section class="ftco-section contact-section ftco-degree-bg " >
      <div class="container">
        <div class="row d-flex mb-5 contact-info">
          <div class="col-md-12 mb-4">
            <h2 class="h2"><b>Contact Information</b></h2>
          </div>
          <div class="w-100"></div>
          <div class="col-md-3">
          <span>Address:<br><p style="color: blue;">Syria Damascus Almazzeh</p></span>
          </div>
          <div class="col-md-3">
             <span>Phone: <br><p style="color: blue;"> +963 931812499</p></span>
          </div>
          <div class="col-md-3">
            <span>Email:<br><p style="color: blue;">Areegsalloum04@gmail.com</p></span>
          </div>
          <div class="col-md-3">
           <span>Website <br> <p style="color: blue;">DiscoverSyriaAR.com</p></span>
          </div>
        </div>
        <div class="row block-9 ft">
          <div class="col-md-6 order-md-last pr-md-5">
            <form action="#">
              <div class="form-group">
                <input type="text" class="form-control " placeholder="Your Name" style="height: 50px;font-size: 15px">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Your Email"style="height: 50px;font-size: 15px">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Subject"style="height: 50px;font-size: 15px">
              </div>
              <div class="form-group">
                <textarea name="" id="" cols="30" rows="7" class="form-control" placeholder="Message"style="font-size: 15px"></textarea>
              </div>
              <div class="form-group">
                <input type="submit" value="Send Message" class="btn btn-primary py-3 px-5"style="font-size: 15px">
              </div>
            </form>
          
          </div>

          <div class="col-md-6">
            <div id="map"></div>
          </div>
        </div>
      </div>
    </section>

  -->

  @endsection