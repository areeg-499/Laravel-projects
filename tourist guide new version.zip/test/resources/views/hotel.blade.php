@extends('layouts.app')


@section('content')


    <div class="hero-wrap js-fullheight" style="background-image: url(bg_1.jpg) " >
      <div class="overlay"></div>
      <div class="container">

        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-9 text-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
           
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Hotels</h1>
            <!---------------------search------------------->
           <div class="col-md-12" style="height: 50px;">
             <form action ="/search" method="post">
             	{{csrf_field()}}
             	<div class="input-group" >
             		<input type="search" name="search" class="form-control" style="height: 50px;">
             		<span class="input-group-prepend">
             			<button type="submit" value="search" class="btn btn-success">Search</button>
             		</span>
             	</div>	
             </form>
           </div>



           <!-------------------------------------------------------------->
          
        </div>
      </div>      
    </div>
  </div>

<!-----------slider---------------->

<div class="con container mt-3" style="width: 100%">


<div id="myCarousel" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
      <li data-target="#myCarousel" data-slide-to="4"></li>
      <li data-target="#myCarousel" data-slide-to="5"></li>
      <li data-target="#myCarousel" data-slide-to="6"></li>
      <li data-target="#myCarousel" data-slide-to="7"></li>
      <li data-target="#myCarousel" data-slide-to="8"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/hotels/AL Qaymariya.jpg" width="100%px" height="700px" >
    </div>
    <div class="carousel-item">
      <img src="images/hotels/alpacha.jpg"width="100%px" height="700px" >
    </div>
    <div class="carousel-item">
      <img src="images/hotels/tirqwaz.jpg"width="100%px" height="700px" >
    </div>

      <div class="carousel-item">
      <img src="images/hotels/SheratonDamascus.jpg" width="100%px" height="700px">
    </div>
      <div class="carousel-item">
      <img src="images/hotels/TALISMAN.jpg"width="100%px" height="700px" >
    </div>
      <div class="carousel-item">
      <img src="images/hotels/Zeitouna Al Sham.jpg"width="100%px" height="700px" >
    </div>
  <div class="carousel-item">
      <img src="images/hotels/Zeitouna Al Sham.jpg"width="100%px" height="700px" >
    </div>

  <div class="carousel-item">
      <img src="images/hotels/Zeitouna Al Sham.jpg"width="100%px" height="700px" >
    </div>
 <div class="carousel-item">
      <img src="images/hotels/Zeitouna Al Sham.jpg"width="100%px" height="700px" >
    </div>
   
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#myCarousel" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

</div>


<!--------the mobile tape-------
<div class="owl-carousel owl-theme">
	@foreach($hotels as $hotel)
    <div class="item">
    	<a href="#"><img src="images/{{$hotel->image}}" width="300px;" height="300px"></a>
    	<div>{{$hotel->SITE}}</div>
    </div>
    @endforeach
</div>
<br>

-->
<!-------------popular hotels---------------->
<div class="container">
	<h1><b>Popular hotels</b></h1>
<div class=" col-lg-12">
          	<div class="row">
          			@foreach($hotels as $hotel)


		    			<div class="col-sm col-md-6 col-lg-4 ftco-animate">
		    				<div class="destination">
		    					<a href="hotel/{{$hotel->id}}" class="img img-2 d-flex justify-content-center align-items-center" name="discover" id="discover"> 
		    			           	<img width="500px" height="300px" src="images/{{$hotel->image}}">
		    			 			<div class="icon d-flex justify-content-center align-items-center">
		    							<span class="icon-link"></span>
		    						</div>
		    					</a>
		    					<div class="text p-3">
		    						<div class="d-flex">
		    							<div class="one">
				    						<h3><a href="hotel/{{$hotel->id}}">{{$hotel->SITE}}</a></h3>
				    						<p class="rate">
				    							<i class="fa fa-star checked"></i>
				    							<i class="fa fa-star checked"></i>
				    							<i class="fa fa-star checked"></i>
				    							<i class="fa fa-star checked"></i>
				    							<i class="fa fa-star "></i>
				    							<span>8 Rating</span>
				    						</p>
			    						</div>
			    						<!--<div class="two">
			    							<span class="price per-price">$40<br><small>/night</small></span>
		    							</div>-->
		    						</div>
		    						<p>Very far, far from countries, where rest and relaxation</p>
		    						<hr>
		    						<p class="bottom-area d-flex">
		    							<span><i class="fa fa-map"></i> Syria</span> 
		    							<span class="ml-auto"><button type="btn-success" style="background-color: #264d00"><a href="hotel/{{$hotel->id}}" style="color: white">Discover</a></button></span>
		    						</p>
		    					</div>
		    				</div>
		    			</div>
     @endforeach	
 </div>
</div>
</div>


@endsection