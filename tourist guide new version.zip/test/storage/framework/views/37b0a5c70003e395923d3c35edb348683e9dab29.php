<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>DiscoverSyria</title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<!----------crowsel-------------->
  <link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- Fonts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" integrity="sha384-XdYbMnZ/QjLh6iI4ogqCTaIjrFk87ip+ekIjefZch0Y+PvJ8CDYtEs1ipDmPorQ+" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700">

    <!-- Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>

<!---bootstrap-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">


<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

<!----------------css------------------->
<!---icon----------->
<link rel="stylesheet" href="https://cdnjs.cloudflare .com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!------------------>

<link rel="stylesheet" type="text/css" href="public/css/style.css">

<style>

body {
font-family: "Times New Roman", Times, serif;
font-size: 200%;

}
.checked{color: orange}

.con{width: 100%;}
</style>
          
</head>

<body id="app-layout" >
  <header style="background-image: url(bg_1.jpg);">
    <nav class="navbar navbar-default navbar-static-top navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light navbar-center ftco-navbar">
  <div class="container " style="background-image: url(bg_1.jpg) ">
    <a href="/home" style="color: pink "><b><h1>  DiscoverSyria</h1></b></a>
          <ul class="nav navbar-nav navbar-expand-lg">
            <li class="nav-item "><a href=" <?php echo e(url('/home')); ?> " style="color: #ffffff;"><b><h3>Home</h3></b></a></li>
            <li class="nav-item"><a href="about" style="color: #ffffff;"><b><h3>About</h3></b></a></li>
            <li class="nav-item "><a href="<?php echo e(url('/places')); ?>" style="color: #ffffff;"><b><h3>Cities</h3></b></a></li>
            <li class="nav-item"><a href="hotels" style="color: #ffffff;"><b><h3>Hotels</h3></b></a></li>
            <li class="nav-item"><a href="<?php echo e(url('restaurants')); ?>"style="color: #ffffff;" ><b><h3>Restaurant & Cafe</h3></b></a></li>
            <li class="nav-item"><a href="<?php echo e(url('/contact')); ?>"style="color: #ffffff;" ><b><h3>Contact</h3></b></a></li>
          </ul>
        
      
    <!-- END nav -->
     <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light navbar-static-top" id="ftco-navbar"style="background-image: url(bg_1.jpg) ">
                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/login')); ?>"  style="color: pink;"><h3>Login</h3></a></li>
                        <li><a href="<?php echo e(url('/register')); ?>" style="color: pink;"><h3>Register</h3></a></li>
                    <?php else: ?>
                         <li><a href="<?php echo e(url('/profile')); ?>"style="color: #ffcccc;"><?php echo e(Auth::user()->name); ?> profile</a></li>
                         <?php if(Auth::user()->role <=2): ?>
                            <li><a href="controll"style="color: #ffcccc;">Control</a></li>
                         <?php endif; ?>
                         <li><a href="<?php echo e(url('/logout')); ?>"style="color: #ffcccc;"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                           
                    <?php endif; ?>
                </ul>
            </div>
       </div>
      </nav>
     </div>
   
    
</header>

    <?php echo $__env->yieldContent('content'); ?>


<footer class=" ftco-footer ftco-bg-dark ftco-section navbar-dark bg-dark ftco-bg-dark" style="color: #ffffff;padding-bottom: 5px;padding-top: 10px;">
      <div class="container">
        <div class="row col-md-12">
          <div class="col-md-4 ">
            <div class="ftco-footer-widget  navbar-left">
              <h2 class="ftco-heading-2" style="color: yellow">DiscoverSyriaAR</h2>
              <p>Away, where to rest and relax and <br>discover new places and tourism.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          
          <div class="col-md-4 ">
            <div class="ftco-footer-widget text-center" >
              <h2 class="ftco-heading-2"style="color: yellow">Used to</h2>
                <ul class="list-unstyled">
                <li class="py-2 d-block">Beach</li>
                <li class="py-2 d-block">Adventure</li>
                <li class="py-2 d-block">Wildlife</li>
                <li class="py-2 d-block">Discover</li>
                <li class="py-2 d-block">Tourism</li>
                <li class="py-2 d-block">Nature</li>
               
              </ul>
            </div>
          </div>


          <div class="col-md-4">
            <div class="ftco-footer-widget  navbar-right">
              <h2 class="ftco-heading-2"style="color: yellow">Have a Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="fa fa-map"></span> Syria Damascus Almazzeh</li>
                  <li><span class="fa fa-phone"></span>+963 931812499</li>
                  <li><span class="fa fa-envelope"></span>Areegsalloum04@gmail.com</li>
                </ul>
              </div>
            </div>
          </div>  
</div>

   <div> 
    
        <div class="col-md-12 text-center"> 
          <hr />          
          <p class="pp text-center"><b>Copyright &copy;2019 DiscoverSyriaAR.All Rights Reserved. <br>Made with <i class="fa fa-heart"></i> by <a href="#" target="_blank">AS</a></p>
                  </div>
               </div>
      </div>
 
    
  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

</div>
</footer>
<!-- JavaScripts-->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/main.js"></script>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>



 <script >
  
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:0,
    nav:false,
    autoplay:true,
autoplayTimeout:3000,
autoplayHoverPause:false,//if mouse in tib move not stop
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})

</script>
<!-------------------for search----------->





</body>
</html>
