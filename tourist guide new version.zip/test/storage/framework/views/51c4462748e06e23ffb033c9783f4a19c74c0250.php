<?php $__env->startSection('content'); ?>


  <?php foreach( $hots as $hotel): ?>

          <div class="a container col-lg-12 col-md-12">
             <div class="row">
              <div class="col-md-12 ftco-animate ">
                <div class="single-slider owl-carousel">

                  <img src="public/images/hotels/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>

          </div>
   <?php endforeach; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>