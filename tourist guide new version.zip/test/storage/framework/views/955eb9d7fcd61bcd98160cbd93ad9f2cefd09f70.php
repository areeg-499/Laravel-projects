<?php $__env->startSection('content'); ?>

  <?php foreach( $hotels as $hotel): ?>
<div class="a container col-lg-12 col-md-12">
            <div class="row">
              <div class="col-md-12 ftco-animate ">
                <div class="single-slider owl-carousel">

                  <img src="public/images/hotels/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>
                  <img src="images/<?php echo e($hotel->image); ?>"/>

                </div>

                  <div class="item">
                    <div class="hotel-img "style="background-image: url(public/images/<?php echo e($hotel->image); ?>);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">hotel1</span>
               </div>
                  </div>
                  <div class="item">
                    <div class="hotel-img" style="background-image: url(images/alandalos.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">hotel2</span>
                  </div>
                  <div class="item">
                    
                      <div class="hotel-img" style="background-image: url(images/Al-Amer.JPEG);"></div>
                    
                    <span class="icon d-flex justify-content-center align-items-center">hotel3</span>
                    </a>
                  </div>

                        <div class="item">
                    <div class="hotel-img" style="background-image: url(images/ajyad.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">hotel4</span>
                  </div>

                        <div class="item">
                    <div class="hotel-img" style="background-image: url(images/afamia.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">hotel5</span>
                  </div>

                        <div class="item">
                    <div class="hotel-img" style="background-image: url(images/aliwan.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">hotel6</span>
                  </div>

                         
                       <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">hotel7</span>
               </div>
                  </div>

                  <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">hotel8</span>
               </div>
                  </div>

                  <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">hotel9</span>
               </div>
                  </div>
                          
                          <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">hotel10</span>
               </div>
                  </div>
                    <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">hotel11</span>
               </div>
                  </div>
                    <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon">hotel12</span>
                     </div>
                  </div>
                </div>
              </div>
            </div>
          <h2>Popular hotels</h2>
      </div>


   
          <div class="col-lg-12">
            <div class="row">
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-1.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#"><?php echo e($hotel->SITE); ?></a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <p><?php echo e($hotel->DESC_ALL); ?></p>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>

              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(public/images/hotels/<?php echo e($hotel->image); ?>);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <img src="public/images/<?php echo e($hotel->image); ?>"/>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#"><?php echo e($hotel->SITE); ?></a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <p><?php echo e($hotel->DESC_ALL); ?></p>

                  
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>

             

              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-3.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#"><?php echo e($hotel->SITE); ?></a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <p><?php echo e($hotel->DESC_ALL); ?></p>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>


              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-4.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#"><?php echo e($hotel->SITE); ?></a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <p><?php echo e($hotel->DESC_ALL); ?></p>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>

   
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>

                 
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#"><?php echo e($hotel->SITE); ?></a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price per-price">$40<br><small>/night</small></span>
                      </div>-->
                    </div>
                    <p><?php echo e($hotel->DESC_ALL); ?></p>
                    <hr>
                    <p class="bottom-area d-flex">
                        <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
            

              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/hotel-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>

            
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#"><?php echo e($hotel->SITE); ?></a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                     
                    </div>
                    <p><?php echo e($hotel->DESC_ALL); ?></p>
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>

                </div>
              </div>
 <?php endforeach; ?>

            </div>
          </div> <!-- .col-md-8 -->
        </div>
      </div>
    </section> <!-- .section -->

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>