<?php $__env->startSection('content'); ?>


<div class="hero-wrap js-fullheight" style="background-image: url('images/bg_1.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-9 ftco-animate mb-5 pb-5 text-center text-md-left" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Discover <br>A new Places</h1>
            <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Find great places to stay, eat, shop, or visit from local experts</p>
          </div>
        </div>
      </div>
    </div>


    
   <!-- <div class="hero-wrap js-fullheight" style="background-image: url('images/bg_1.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-9 text-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
            <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.html">Home</a></span> <span>Cities</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Let`s Go</h1>
          </div>
        </div>
      </div>
    </div>

-->
<div class="a container col-lg-12">
            <div class="row">
              <div class="col-md-12 ftco-animate ">
                <div class="single-slider owl-carousel">

                  <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">damascus</span>
               </div>
                  </div>
                  <div class="item">
                    <div class="hotel-img" style="background-image: url(images/hotel-3.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">Aleppo</span>
                  </div>
                  <div class="item">
                    
                      <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
                    
                    <span class="icon d-flex justify-content-center align-items-center">Palmyra</span>
                    </a>
                  </div>

                        <div class="item">
                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">Al-Suwayda</span>
                  </div>

                        <div class="item">
                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">Latakia</span>
                  </div>

                        <div class="item">
                    <div class="hotel-img" style="background-image: url(images/hotel-4.jpg);"></div>
                    <span class="icon d-flex justify-content-center align-items-center">Homs</span>
                  </div>

                         
                       <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">Hamah</span>
               </div>
                  </div>

                  <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">Tartus</span>
               </div>
                  </div>

                  <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">Daraa</span>
               </div>
                  </div>
                          
                          <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">Al-Hasakah</span>
               </div>
                  </div>
                    <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">Al-Qunaytirah</span>
               </div>
                  </div>
                    <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">Dayr-AlZwr</span>
               </div>
                  </div>
                   <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">AlRaqqa</span>
               </div>
                  </div>  

                         
                         <div class="item">

                    <div class="hotel-img "style="background-image: url(images/hotel-2.jpg);" ></div>
                    <div class="icon d-flex justify-content-center align-items-center">
                <span class="icon">Idlib</span>
               </div>
                  </div>  




                </div>
              </div>
            </div>
          </div>




  <section class="ftco-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 sidebar order-md-last ftco-animate">
            <div class="sidebar-wrap ftco-animate">
              <h3 class="heading mb-4">Find City</h3>
              <form action="#">
                <div class="fields">
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Destination, City">
                  </div>
                  <!--
                  <div class="form-group">
                    <div class="select-wrap one-third">
                      <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                      <select name="" id="" class="form-control" placeholder="Keyword search">
                        <option value="">Select Location</option>
                        <option value="">San Francisco USA</option>
                        <option value="">Berlin Germany</option>
                        <option value="">Lodon United Kingdom</option>
                        <option value="">Paris Italy</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <input type="text" id="checkin_date" class="form-control checkin_date" placeholder="Date from">
                  </div>
                  <div class="form-group">
                    <input type="text" id="checkout_date" class="form-control checkout_date" placeholder="Date to">
                  </div>
                  <div class="form-group">
                    <div class="range-slider">
                      <span>
                        <input type="number" value="25000" min="0" max="120000"/> -
                        <input type="number" value="50000" min="0" max="120000"/>
                      </span>
                      <input value="1000" min="0" max="120000" step="500" type="range"/>
                      <input value="50000" min="0" max="120000" step="500" type="range"/>
                      </svg>
                    </div>
                  </div>-->
                  <div class="form-group">
                    <input type="submit" value="Search" class="btn btn-primary py-3 px-5">
                  </div>
                </div>
              </form>
            </div>
            <div class="sidebar-wrap ftco-animate">
              <h3 class="heading mb-4">Star Rating</h3>
              <form method="post" class="star-rating">
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1">
                    <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i></span></p>
                  </label>
                </div>
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1">
                     <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i></span></p>
                  </label>
                </div>
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1">
                    <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i></span></p>
                 </label>
                </div>
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1">
                    <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i></span></p>
                  </label>
                </div>
                <div class="form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1">
                    <p class="rate"><span><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i></span></p>
                  </label>
                </div>
              </form>
            </div>
          </div><!-- END-->
          <div class="col-lg-9">
            <div class="row">
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/destination-3.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Damascus</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price">$200</span>
                      </div>-->
                    </div>
                    <p>Damascus is the capital of Syria</p>
                    <!--<p class="days"><span>2 days 3 nights</span></p>-->
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/destination-4.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Aleppo</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price">$200</span>
                      </div>-->
                    </div>
                    <p>The second largest city of Syria Aleppo <mark>Alshahba</mark></p>
                    <!--<p class="days"><span>2 days 3 nights</span></p>-->
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/destination-1.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Latakia</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price">$200</span>
                      </div>-->
                    </div>
                    <p>Overlooking the sea and full of magnificent forests</p>
                    <!--<p class="days"><span>2 days 3 nights</span></p>-->
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/destination-2.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Tartus</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                    <!--  <div class="two">
                        <span class="price">$200</span>
                      </div>-->
                    </div>
                    <p>The second lung of Syria overlooks the sea and is full of magnificent forests</p>
                    <!--<p class="days"><span>2 days 3 nights</span></p>-->
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/destination-5.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Palmyra</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                      <!--<div class="two">
                        <span class="price">$200</span>
                      </div>-->
                    </div>
                    <p>An ancient city of the most important ancient kingdoms of Syria</p>
                    <!--<p class="days"><span>2 days 3 nights</span></p>-->
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-sm col-md-6 col-lg-4 ftco-animate">
                <div class="destination">
                  <a href="#" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/destination-6.jpg);">
                    <div class="icon d-flex justify-content-center align-items-center">
                      <span class="icon-link"></span>
                    </div>
                  </a>
                  <div class="text p-3">
                    <div class="d-flex">
                      <div class="one">
                        <h3><a href="#">Hamah</a></h3>
                        <p class="rate">
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star"></i>
                          <i class="icon-star-o"></i>
                          <span>8 Rating</span>
                        </p>
                      </div>
                    <!--  <div class="two">
                        <span class="price">$200</span>
                      </div>-->
                    </div>
                    <p> one of the oldest inhabited areas in the Middle East and even in the world</p>
                    <!--<p class="days"><span>2 days 3 nights</span></p>-->
                    <hr>
                    <p class="bottom-area d-flex">
                      <span><i class="icon-map-o"></i> Syria</span> 
                      <span class="ml-auto"><a href="#">Discover</a></span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div></div></div></section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>