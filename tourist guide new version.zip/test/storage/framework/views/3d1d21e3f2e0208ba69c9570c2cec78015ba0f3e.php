<?php $__env->startSection('content'); ?>


    <div class="hero-wrap js-fullheight" style="background-image: url(bg_1.jpg) " >
      <div class="overlay"></div>
      <div class="container">

        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-9 text-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
           <h1 class="mb-4" data-scrollax="properties: { translateY: '70%', opacity: 1.6 }" style="font-size: 20px">Discover <br>A new Places</h1>
            <p data-scrollax="properties: { translateY: '70%', opacity: 1.6 }">Find great places to stay, eat, shop, or visit from local experts</p>

        </div>
    </div>
</div>
</div>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>