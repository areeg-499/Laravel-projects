<?php $__env->startSection('content'); ?>

 <div class="hero-wrap js-fullheight" style="background-image: url(bg_1.jpg) " >
      <div class="overlay"></div>
      <div class="container">

        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-9 text-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">

            <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-2"><a href="index.html" style="color: #990000">Home</a></span> <span style="color: #332200">About</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }" style="font-size: 30px;color: #73264d">About us</h1>
           </div>
           </div>
           </div>
           </div> 

<br/>

<div class="container">
        <div class="row mb-5" >
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2" style="color: #eaeafa ; background-color: #4747d1 ;height: 40px; text-align: center;"> <b>What we do</b></h2>
              <p style="color: #862d2d"> We are a team of 4 people who collaborated on this project which provides many services to tourists from all over the world about our country Syria.</p>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2" style="color: #eaeafa ; background-color:  #4747d1;height: 40px; text-align: center;"><b>Our mission</b></h2>
            <p style="color: #862d2d">Our mission To accomplish our work to the fullest delivery of information needed by the user easily and clearly</p>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2" style="color: #eaeafa ; background-color: #4747d1;height: 40px; text-align: center;"><b>Our goal</b></h2>
              <p style="color: #862d2d">Our goal is to reach what we have achieved to the maximum number of users and use the application easily and provide all the user needs of information and services about tourism in our country</p>


             
              
            </div>
          </div>
        </div>
    </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>