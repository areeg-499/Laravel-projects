<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Control</div>
                <div class="panel-body"> 

                  <div class="bs-example" data-example-id="panel-without-body-with-table">
                    <div class="panel panel-default">
                      <div class="panel-heading">Panel heading</div>

                      <table class="table">
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>E-mail</th>
                            <th>Role</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php foreach($users as $user): ?>  
                          <tr>
                            <th scope="row"><?php echo e($user->id); ?></th>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                              <div class="form-group" style="margin-bottom: 0px;">
                                  <form method="post">
                                    <select class="form-control" name="role">
                                      <option value="1" <?php echo e((($user->role) == 1) ? 'selected' : null); ?> >Admin</option>
                                      <option value="2"  <?php echo e((($user->role) == 2) ? 'selected' : null); ?> >Manager</option>
                                      <option value="3"  <?php echo e((($user->role) == 3) ? 'selected' : null); ?> >User</option>
                                    </select>
                                  </form>
                              </div>
                            </td>
                          </tr>
                        <?php endforeach; ?>
                        </tbody>
                      </table>
                    </div> 
                  </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>