<?php $__env->startSection('content'); ?>

<div class="container"> 


<?php foreach($results as $hotel): ?>

<h2>Name of hotel:</h2><?php echo e($hotel->SITE); ?><hr />

<img src="/images/<?php echo e($hotel->image); ?>"; width="100%"; height="500px"/>

<h2>Location :</h2><?php echo e($hotel->CITY); ?><?php echo e($hotel->street); ?><hr />

<h2>The rank of hotel:</h2><?php echo e($hotel->Rank); ?><hr />

<h2>telephone :</h2><?php echo e($hotel->telephone); ?><hr />
<h2>website :</h2><?php echo e($hotel->website); ?><hr />

<h2>Description :</h2><?php echo e($hotel->DESC_ALL); ?><hr />

<?php endforeach; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>